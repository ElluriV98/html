function myFunction() {
    var numbers = /^[0-9]+$/;
      if(price.value.match(numbers))
      {
      return true;
      }
      else
      {
      alert("Please input numeric characters only");
      return false;
      }
}