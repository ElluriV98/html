function myFunction() {
    var n = document.getElementById("name1").value;
    var numbers = /^[0-9]+$/;
    var a=0,b=0,c=0,d=0;
    if (n == "") {
        alert("Enter your name");
       a=1;

    }
    // if (n.length > 2 || n.length < 65) {
    //     alert("Name should be more than 2 and less than 65");
    //     b=1;

    // }
    if (dol.value == "") {
        alert("Enter Date Of Launch");
        c=1;
    }
    if (price.value.match(numbers)) {
        return true;
    }
    else {
        alert("Please input numeric characters only");
        return false;
        d=1;
    }
    if(a==0&&c==0&&d==0){
        window.location="EditMovieStatus.html";
    }
}
