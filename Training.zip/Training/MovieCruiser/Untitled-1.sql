IF EXISTS (SELECT * FROM sys.databases WHERE title = N'moviecruiser')
BEGIN
	DROP DATABASE moviecruiser
	CREATE DATABASE moviecruiser
END
ELSE
BEGIN
	CREATE DATABASE moviecruiser
END
GO

USE moviecruiser
GO

/****** Object:  Table [dbo].[cart]    Script Date: 7/30/2019 11:46:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[cart](
	[ct_id] [int] IDENTITY(1,1) NOT NULL,
	[ct_us_id] [bigint] NULL,
	[ct_mc_id] [bigint] NULL,
 CONSTRAINT [PK_cart] PRIMARY KEY CLUSTERED 
(
	[ct_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[product]    Script Date: 7/30/2019 11:46:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[movie_cruiser](
	[mc_id] [bigint] IDENTITY(1,1) NOT NULL,
	[mc_title] [varchar](100) NULL,
	[mc_box_office] [decimal](8, 2) NULL,
	[mc_active] [varchar](3) NULL,
	[mc_date_of_launch] [date] NULL,
	[mc_genre] [varchar](45) NULL,
	[mc_has_teaserteaser] [varchar](3) NULL,
 CONSTRAINT [PK_movie_cruiser] PRIMARY KEY CLUSTERED 
(
	[mc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[user]    Script Date: 7/30/2019 11:46:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[user](
	[us_id] [bigint] IDENTITY(1,1) NOT NULL,
	[us_title] [varchar](60) NULL,
 CONSTRAINT [PK_user] PRIMARY KEY CLUSTERED 
(
	[us_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
ALTER TABLE [dbo].[cart]  WITH CHECK ADD  CONSTRAINT [ct_mc_fk] FOREIGN KEY([ct_mc_id])
REFERENCES [dbo].[movie_cruiser] ([mc_id])
GO
ALTER TABLE [dbo].[cart] CHECK CONSTRAINT [ct_mc_fk]
GO
ALTER TABLE [dbo].[cart]  WITH CHECK ADD  CONSTRAINT [ct_us_fk] FOREIGN KEY([ct_us_id])
REFERENCES [dbo].[user] ([us_id])
GO
ALTER TABLE [dbo].[cart] CHECK CONSTRAINT [ct_us_fk]
GO


-- Include table data insertion, updation, deletion and select scriptuse truyum

/*  SQL query to insert values into table movies_item (5 rows affected) */

SET IDENTITY_INSERT movie_cruiser  ON
insert into movie_cruiser(mc_id,mc_title,mc_box_office,mc_active,mc_date_of_launch,mc_genre,mc_has_teaser)values
(1, 'sandwich', 99.00, 'yes', '2017-03-03', 'Main Course', 'yes'),
(2, 'Burger', 129.00, 'yes', '2017-12-12', 'Main Course', 'yes'),
(3, 'pizza', 149.00, 'yes', '2018-12-03', 'Main Course', 'no'),
(4, 'French Fries', 57.00, 'yes', '2017-12-07', 'Starters', 'yes'),
(5, 'Chocolate Browine', 32.00, 'yes', '2015-12-12', 'Desert', 'no')
SET IDENTITY_INSERT movie_cruiser  OFF

/*  SQL query to get all menu items */

select * from movie_cruiser
select mc_title,mc_box_office,mc_active,mc_date_of_launch,mc_genre,mc_has_teaser from movie_cruiser

/* SQL query to get all menu items which after launch date and is active. */

select mc_title,mc_box_office,mc_genre,mc_has_teaser from movie_cruiser where mc_date_of_launch< GETDATE() and mc_active='yes'

/* SQL query to get a menu items based on Menu Item Id */

select mc_title,mc_box_office,mc_active,mc_date_of_launch,mc_genre,mc_has_teaser from movie_cruiser where mc_id=1

/* update SQL movie_cruisers table to update all the columns values based on Menu Item Id */

update movie_cruiser set mc_title='veg Sandwich',mc_box_office=129.00,mc_active='yes',mc_date_of_launch='2018-03-03',mc_genre='Starter',mc_has_teaser='no' where mc_id=1



/* SQL query to insert values into table user (3 rows affected) */
SET IDENTITY_INSERT [dbo].[user] ON
insert into [dbo].[user](us_id,us_title) values (1,'vineela'),(2,'rohitha'),(3,'gowthami')
SET IDENTITY_INSERT [dbo].[user] OFF

select * from [dbo].[user];


/* SQL query to insert values into table cart (3 rows affected)  */ 
SET IDENTITY_INSERT cart ON
insert into cart(ct_id,ct_us_id,ct_mc_id) values(1,1,1)
insert into cart(ct_id,ct_us_id,ct_mc_id) values(2,1,1),(3,1,2)

SET IDENTITY_INSERT cart  OFF

select * from  cart


/* SQL query to get all menu items in a particular user’s cart  */

select m.mc_title,m.mc_has_teaser,mc_box_office from cart c,movie_cruiser m where c.ct_us_id = 1 and c.ct_mc_id = m.mc_id
select mc_title,mc_has_teaser,mc_box_office from movie_cruiser where mc_id in(select ct_mc_id from cart where ct_us_id=1)

/*  SQL query to get the total_box_office of all menu items in a particular user’s cart */
select sum(m.mc_box_office) from cart c,movie_cruiser m where c.ct_us_id = 1  and c.ct_mc_id = m.mc_id
select sum(mc_box_office) as Tota_box_office from movie_cruiser where mc_id in(select ct_mc_id from cart where ct_us_id=1)


/* SQL query to remove a menu items from Cart based on User Id and Menu Item Id */
 delete from cart where ct_id=1 and ct_mc_id=2




